const express = require('express');
const User = require('../model/User');

const route = express.Router();

// Create a new user
route.post('/add', async (req, res) => {
    const user = await User.create(req.body);
    res.json(user);
});

// get all users
route.get('/', async (req, res) => {
    const user = await User.find();
    res.json(user);
});

// update a user by ID
route.put('/:id', async (req, res) => {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(user);
});

// delete a user by ID
route.delete('/:id', async (req, res) => {
    const user = await User.findByIdAndDelete(req.params.id);
    res.json({ message: `user deleted successfully ${user}` });
});

module.exports = route;