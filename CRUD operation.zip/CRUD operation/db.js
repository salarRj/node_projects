const express = require('express');
const mongoose = require('mongoose');

const Mongoose_URL = "mongodb+srv://admin:boLrP9U1Q66csEnd@cluster0.lppi6q3.mongodb.net/personsDB?retryWrites=true&w=majority";


const connectDB = async () => {
    try {
        await mongoose.connect( Mongoose_URL);
        console.log("mongoDB connected")
    } catch (error) {
        console.log(error);
    }
}


module.exports = connectDB;

