const express = require('express');
const app = express();
const port = 3000;
// import database connection
const connectDB = require('./db');
// import user routes
const userRoutes = require('./routes/userRoutes');



// connect to database
connectDB();

app.use('/users', userRoutes);


app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});